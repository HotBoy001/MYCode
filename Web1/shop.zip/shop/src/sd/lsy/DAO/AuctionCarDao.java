package sd.lsy.DAO;

public interface AuctionCarDao {

}
