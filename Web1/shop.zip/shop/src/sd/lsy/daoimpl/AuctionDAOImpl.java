package sd.lsy.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import sd.lsy.DAO.AuctionDAO;
import sd.lsy.DO.AuctionDO;
import sd.lsy.DO.User;
import sd.lsy.SQL.SqlCon;


public class AuctionDAOImpl implements AuctionDAO{
	private static Map<String,AuctionDO> auctionList = new HashMap<String,AuctionDO>();

	static{
//		for(int i=0;i<20;i++){
//			AuctionDO auc = new AuctionDO("��Ʒ"+i,"description"+i,100+(int)(Math.random()*100));
//			auctionList.put(auc.getId(),auc);
//		}
		AuctionDO ad =null;
		String sql="";
		//�����ݿ��ж�ȡȫ����Ʒ
		sql="select * from auctiondo";
		ResultSet rs= SqlCon.getResultSet(sql);
		try {
			while(rs.next()){
				ad=new AuctionDO();
				ad.setId(rs.getString("id"));
				ad.setTitle(rs.getString("title"));
				ad.setDescription(rs.getString("description"));
				ad.setPrice(rs.getFloat("price"));
				auctionList.put(ad.getId(),ad);//����auctionList
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public AuctionDO getAuction(String id) {
		return auctionList.get(id);
	}

	@Override
	public void addAuction(AuctionDO auc) {
		auctionList.put(auc.getId(),auc);
	}

	@Override
	public List<AuctionDO> getAll() {
		return new ArrayList<AuctionDO>(auctionList.values());
	}

	@Override
	public void deleteAuction(String id) {
		auctionList.remove(id);
	}

	@Override
	public void updateAuction(AuctionDO auc) {
		auctionList.put(auc.getId(), auc);
	}
}

