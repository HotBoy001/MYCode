package sd.lsy.DAO;

import sd.lsy.DO.User;

public interface  UserDao {
     //��¼���
	 public User check(String name,String password);
	 
}
