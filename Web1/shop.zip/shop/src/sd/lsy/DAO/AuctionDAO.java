package sd.lsy.DAO;

import java.sql.SQLException;
import java.util.List;

import sd.lsy.DO.AuctionDO;

public interface AuctionDAO {
	/**
	 * 浠庢暟鎹簮涓幏鍙栨寚瀹歩d瀵瑰簲鐨勫晢鍝佷俊鎭�
	 * @param id
	 * @return
	 */
    public AuctionDO getAuction(String id)  throws SQLException ;
    /**
     * 娣诲姞涓�鏉″晢鍝佷俊鎭埌鏁版嵁婧愪腑
     * @param auc锛氳娣诲姞鐨勫晢鍝佸璞�
     */
    public void addAuction(AuctionDO auc)throws SQLException;
    /**
     * 鑾峰彇鏁版嵁婧愪腑鐨勫叏閮ㄧ殑鍟嗗搧鍒楄〃
     * @return
     */
    public List<AuctionDO> getAll() throws SQLException;
    /**
     * 閫氳繃鍟嗗搧id鍒犻櫎涓�鏉″晢鍝佽褰�
     * @param id锛氳鍒犻櫎鐨勫晢鍝佺殑id
     */
    public void deleteAuction(String id) throws SQLException;
    /**
     * 淇敼鏁版嵁婧愪腑鐨勬寚瀹氬晢鍝佷俊鎭�
     * @param auc:瑕佷慨鏀圭殑鍟嗗搧鍜屽叾淇敼鍚庣殑淇℃伅
     */
    public void updateAuction(AuctionDO auc) throws SQLException;

}
