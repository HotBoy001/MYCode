package sd.lsy.SERVLET;

import java.io.IOException;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sd.lsy.DO.User;
import sd.lsy.daoimpl.UserDaoImpl;

@WebServlet(name="UserLogin",urlPatterns="/UserLogin")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		String name=request.getParameter("username");
		String password=request.getParameter("password");
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
        String date =df.format(new Date());//Ϊ��ȡ��ǰϵͳʱ��
		System.out.println("@@@@@@@@@@@@@@@@"+name+password);
		ArrayList<String> error=new ArrayList<>();
		UserDaoImpl udi=new UserDaoImpl();
		User user=null;
		user=udi.check(name, password);
		if(user!=null)
		{
			//�����û���¼ʱ��
			user.setDate(date);
			//�����û���Ϣ
		    HttpSession session= request.getSession();
		    session.setAttribute("user", user);
			response.sendRedirect("AuctionListServlet");
			//request.getRequestDispatcher("login.jsp").forward(request, response);
		}else{
			error.add("��½ʧ�ܣ������û����������룡");
			request.setAttribute("error", error);
			response.sendRedirect("login.jsp");
		}
	}

}
