package infoSql;

import sd.lsy.DO.AuctionDO;
import sd.lsy.SQL.SqlCon;
//����20�����ݲ������ݿ�
public class Sqlmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sql="";
		for(int i=0;i<20;i++){
			AuctionDO auc = new AuctionDO("��Ʒ"+i,"description"+i,100+(int)(Math.random()*100));
			sql="insert into auctiondo values("+"'"+auc.getId()+"',"+
					                            "'��Ʒ"+i+"',"+
					                            "'description"+i+"',"+
					                            "'"+100+(int)(Math.random()*100)+"'"+")";
			System.out.println(sql);
			SqlCon.execute(sql);
		}
	}

}
