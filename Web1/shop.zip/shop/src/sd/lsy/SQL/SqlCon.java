package sd.lsy.SQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
 

public class SqlCon {
 
    //ָ��������
    protected static String driver = "com.mysql.jdbc.Driver";
    //ָ�����ʵ�URL
    protected static String url = "jdbc:mysql://localhost:3306/shop";
    //MySQL�û���
    protected static String user = "root";
    //MySQL����
    protected static String password = "123456";
    //��ʼConnection
    protected static Connection connection = null;
 
    //��������
    public static Connection getConnection() {
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, user, password);
            return connection;
        } catch (ClassNotFoundException | SQLException e) {
            return null;
        }
    }
 
    //��ȡ�����
    public static ResultSet getResultSet(String sql) {
        Statement statement;
        ResultSet resultSet = null;
        Connection conn = getConnection();
        if (conn != null) {
            System.out.println("���ӳɹ���");
            try {
                statement = conn.createStatement();
                resultSet = statement.executeQuery(sql);
            } catch (Exception e) {
            }
            return resultSet;
        } else {
            return null;
        }
    }
 
    //�жϽ�����Ƿ�Ϊ��
    public static boolean isResultSetNull(String sql) {
        int count = 0;
        ResultSet resultSet = getResultSet(sql);
        try {
            while (resultSet.next()) {
                count += 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(SqlCon.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (count == 0) {
            return true;
        } else {
            return false;
        }
    }
 
    //�Ƿ�ִ��
    public static boolean execute(String sql) {
        boolean success;
        Statement statement;
        Connection conn = getConnection();
        if (conn != null) {
            try {
                statement = conn.createStatement();
                success = statement.execute(sql);
            } catch (Exception e) {
                success = false;
            }
        } else {
            success = false;
        }
        return success;
    }
 
    //�ͷ�����
    public static void releaseConnection() {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (Exception e) {
        }
    }
}