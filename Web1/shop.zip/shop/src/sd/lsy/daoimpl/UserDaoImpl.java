package sd.lsy.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;

import sd.lsy.DAO.UserDao;
import sd.lsy.DO.User;
import sd.lsy.SQL.SqlCon;

public class UserDaoImpl implements UserDao{

	@Override
	public User check(String name, String password) {
		// TODO Auto-generated method stub
		User user=null;
		String sql="";
		sql="select * from user where name='"+name+"'and password='"+password+"' ";
		ResultSet rs=null;
		try {
			rs= SqlCon.getResultSet(sql);
			if(rs!=null){
			if(rs.next())
			{
				user=new User(rs.getInt("Id"),rs.getString("name"),rs.getString("password"),
				rs.getString("phone"),rs.getString("address"),rs.getString("sex"),rs.getString("email"));
			}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

}
